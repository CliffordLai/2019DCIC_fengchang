#include <Rcpp.h>
using namespace Rcpp;

//' @export
//[[Rcpp::export]]
NumericVector conEndpoint(NumericVector x){
   int n = x.size();
   NumericVector endpoint(n);
   int h = 1;
   endpoint[0] = 1;

   for(int i=1; i<n; i++){
     if((x[i]-x[i-1])!=1){
       endpoint[h] = i-1+1;
       endpoint[h+1] = i+1;
       h = h+2;
     }
   }
   endpoint[h] = n;

   NumericVector sendpoint(h);
   sendpoint = endpoint[Range(0,h)];

   return sendpoint;
}
