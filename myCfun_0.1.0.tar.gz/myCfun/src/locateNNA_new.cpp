#include <Rcpp.h>
using namespace Rcpp;

// abs for float
double abs3(double x) { return std::abs(x); }

//' @export
//[[Rcpp::export]]
NumericVector find1in2(NumericVector x1, NumericVector x2){
  int n1 = x1.size();
  int n2 = x2.size();
  int eps1 = 0;
  int eps2 = 0;
  NumericVector res(n1);

  for(int i=0; i<n1; i++){
    if(i==0){
      res[i] = 1;
    }else{
      res[i] = res[i-1];
    }
    eps1 = abs3(x1[i]-x2[res[i-1]-1]);
    for(int j=res[i]; j<n2; j++){
      eps2 = abs3(x1[i]-x2[j]);
      if(eps2<eps1){
        eps1 = eps2;
        res[i] = j+1;
      }else{
        break;
      }
    }
  }
  return res;
}

//' @export
//[[Rcpp::export]]
NumericVector locateNNA(NumericVector x){
   int n = x.size();
   NumericVector res(n+1);
   res[0] = 1;
   for(int i=0; i<n; i++){
	if(x[i] == 1){
	    res[i+1] = res[i]+1;
	}else{
		res[i+1] = 1;
	}
   }
   return res;
}

//' @export
//[[Rcpp::export]]
NumericMatrix locateKNNA(NumericVector left_margin,
                         NumericVector right_margin,
                         int kmax){
   int n = left_margin.size();
   int d, dabs,h,hm;
   NumericMatrix res(n, kmax+3);

   for(int i=0; i<n; i++){
	   d = left_margin[i]-right_margin[i];
	   dabs = abs(d);

	   if(d>=0){
	     res(i,kmax) = right_margin[i];
	     res(i,kmax+1) = left_margin[i];
	     res(i,kmax+2) = dabs;
	   }else{
	     res(i,kmax) = left_margin[i];
	     res(i,kmax+1) = right_margin[i];
	     res(i,kmax+2) = dabs;
	   }

	   if(dabs>=kmax){
		   if(d>0){
		     for(int j=0; j<kmax; j++){
		       res(i,j)= right_margin[i]+j;
		     }
		   }else if(d<0){
		     for(int j=0; j<kmax; j++){
		       res(i,j)= -left_margin[i]-j;
		     }
		   }
	   }else{
	     if(d==0){
	       for(int j=0; j<kmax; j++){
	         h = j/2;
	         hm = j%2;
	         if(hm==0){
	           res(i,j)= right_margin[i]+h;
	         }else{
	           res(i,j)= -left_margin[i]-h;
	         }
	       }
	     }else if(d>0){
	       for(int j=0; j<dabs; j++){
	         res(i,j)= right_margin[i]+j;
	       }

	       for(int j=dabs; j<kmax; j++){
	         h = (j-dabs)/2;
	         hm = (j-dabs)%2;
	         if(hm==0){
	           res(i,j)= right_margin[i]+dabs+h;
	         }else{
	           res(i,j)= -left_margin[i]-h;
	         }
	       }
	     }else if(d<0){
	       for(int j=0; j<dabs; j++){
	         res(i,j)= -left_margin[i]-j;
	       }

	       for(int j=dabs; j<kmax; j++){
	         h = (j-dabs)/2;
	         hm = (j-dabs)%2;
	         if(hm==0){
	           res(i,j)= right_margin[i]+h;
	         }else{
	           res(i,j)= -left_margin[i]-dabs-h;
	         }
	       }
	     }
	   }
   }
   return res;
}

//' @export
//[[Rcpp::export]]
NumericVector wModeFillMat(List UNset,
                           NumericMatrix y_Mat,
                           NumericMatrix weight){
  double eps = pow(10,-7);
  int n_na = UNset.size();
  int K = y_Mat.ncol();
  NumericVector nafill(n_na);

  for(int i=0;i<n_na;i++){
    NumericVector x = UNset[i];
    int J = x.size();
    NumericVector xw(J);

    for(int k=0; k<K; k++){
      for(int j=0; j<J; j++){
        if(abs3(y_Mat(i,k)-x[j])< eps ){
          xw[j] = xw[j]+weight(i,k);
          break;
        }
      }
    }

    // Find the value with most weights
    int choose_j = 0;
    for(int j=1; j<J; j++){
      if(xw[j]>xw[choose_j]){
        choose_j =j;
      }
    }
    nafill[i] = x[choose_j];
  }

  return nafill;
}

