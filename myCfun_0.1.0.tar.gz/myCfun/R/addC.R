#' @useDynLib myCfun
#' @importFrom Rcpp sourceCpp
NULL
